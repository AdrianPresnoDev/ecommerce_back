export interface Collection {
  id: string;
  title: string;
  slug: string;
  description: string;
  longDescription: string;
  category: string;
  color: string;
  heroImage: string;
}

export const collections: Collection[] = [
  {
    id: "1",
    title: "Abstracto Contemporáneo",
    slug: "abstracto-contemporaneo",
    description: "Expresiones libres de color y forma que desafían la percepción",
    longDescription: "Una colección que celebra la libertad creativa sin límites. Cada obra es una exploración del color, la textura y la forma, donde las reglas tradicionales se rompen para dar paso a expresiones puras de emoción. Estas piezas invitan al espectador a interpretar libremente, creando su propia narrativa visual.",
    category: "Abstracto",
    color: "from-purple-500 to-pink-500",
    heroImage: "https://images.unsplash.com/photo-1525434486320-567654c1f256?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWJyYW50JTIwYWJzdHJhY3QlMjBwYWludGluZyUyMHRleHR1cmV8ZW58MXx8fHwxNzc0NjA2MDM2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    id: "2",
    title: "Retratos Expresivos",
    slug: "retratos-expresivos",
    description: "Capturando la esencia y emoción de la figura humana",
    longDescription: "Esta colección es un viaje íntimo a través del alma humana. Cada retrato no solo captura rasgos físicos, sino que busca revelar la personalidad, las emociones ocultas y las historias no contadas de cada sujeto. La técnica clásica se encuentra con la sensibilidad contemporánea.",
    category: "Retrato",
    color: "from-blue-500 to-cyan-500",
    heroImage: "https://images.unsplash.com/photo-1766169776548-56dad82f5bd2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdCUyMHBhaW50aW5nJTIwY2xhc3NpY2FsJTIwYXJ0fGVufDF8fHx8MTc3NDYwNjAzNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    id: "3",
    title: "Paisajes Oníricos",
    slug: "paisajes-oniricos",
    description: "Naturaleza reimaginada con una paleta vibrante",
    longDescription: "Los paisajes de esta colección no son meras representaciones de lugares reales, sino visiones oníricas donde la naturaleza se transforma en poesía visual. Cada obra transporta al espectador a mundos donde los colores danzan y las formas naturales se reinventan.",
    category: "Paisaje",
    color: "from-green-500 to-emerald-500",
    heroImage: "https://images.unsplash.com/photo-1763491905755-185326526e9e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZXJlbmUlMjBsYW5kc2NhcGUlMjBuYXR1cmUlMjBwYWludGluZ3xlbnwxfHx8fDE3NzQ2MDYwMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    id: "4",
    title: "Minimalismo Moderno",
    slug: "minimalismo-moderno",
    description: "Menos es más: elegancia en su forma más pura",
    longDescription: "Esta colección representa la búsqueda de la esencia a través de la simplicidad. Cada obra está despojada de todo elemento superfluo, dejando solo lo esencial: forma, color y espacio. El resultado son piezas contemplativas que aportan serenidad y sofisticación a cualquier ambiente.",
    category: "Minimalista",
    color: "from-gray-700 to-gray-900",
    heroImage: "https://images.unsplash.com/photo-1770009971150-f50bc7d373a4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnZW9tZXRyaWMlMjBtaW5pbWFsaXN0JTIwYXJ0JTIwY2xlYW58ZW58MXx8fHwxNzc0NjA2MDM3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  }
];

export function getCollectionBySlug(slug: string): Collection | undefined {
  return collections.find(collection => collection.slug === slug);
}
