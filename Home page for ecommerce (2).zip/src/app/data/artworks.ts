export interface Artwork {
  id: string;
  title: string;
  price: number;
  image: string;
  images: string[];
  category: string;
  year: number;
  dimensions: {
    width: number;
    height: number;
    depth: number;
  };
  technique: string;
  materials: string[];
  description: string;
  inspiration: string;
  available: boolean;
  edition: string;
  frameOptions: {
    id: string;
    name: string;
    price: number;
  }[];
}

export const artworks: Artwork[] = [
  {
    id: "1",
    title: "Sinfonía Abstracta",
    price: 890,
    image: "https://images.unsplash.com/photo-1638794224302-ed17a3ff0db9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGNvbnRlbXBvcmFyeSUyMGFydHdvcmslMjBjYW52YXN8ZW58MXx8fHwxNzc0NTMwODgxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    images: [
      "https://images.unsplash.com/photo-1638794224302-ed17a3ff0db9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGNvbnRlbXBvcmFyeSUyMGFydHdvcmslMjBjYW52YXN8ZW58MXx8fHwxNzc0NTMwODgxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      "https://images.unsplash.com/photo-1766289496802-6a8b6977ca55?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMG1vZGVybiUyMHBhaW50aW5nJTIwYXJ0JTIwZ2FsbGVyeXxlbnwxfHx8fDE3NzQ1MzA4ODB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      "https://images.unsplash.com/photo-1769461766792-3993f0ab1b02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYWJzdHJhY3QlMjBhcnQlMjBibHVlfGVufDF8fHx8MTc3NDUzMDg4Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    ],
    category: "Abstracto",
    year: 2024,
    dimensions: {
      width: 100,
      height: 120,
      depth: 4
    },
    technique: "Acrílico sobre lienzo",
    materials: ["Acrílico de alta calidad", "Lienzo de algodón 100%", "Bastidor de madera de pino"],
    description: "Una explosión de colores vibrantes que dialogan entre sí, creando una composición dinámica que captura la energía del movimiento abstracto contemporáneo. Las capas de pintura aplicadas con espátula y pincel crean texturas ricas que invitan al espectador a explorar cada rincón de la obra.",
    inspiration: "Esta pieza nació durante un viaje a la costa mediterránea, donde los colores del atardecer se fundían con las aguas cristalinas. Quise capturar esa sensación de alegría y libertad que sentí al observar cómo la naturaleza crea sus propias sinfonías visuales sin seguir reglas establecidas.",
    available: true,
    edition: "Pieza única",
    frameOptions: [
      { id: "none", name: "Sin marco", price: 0 },
      { id: "natural", name: "Marco natural de roble", price: 120 },
      { id: "black", name: "Marco negro moderno", price: 100 },
      { id: "white", name: "Marco blanco minimalista", price: 100 }
    ]
  },
  {
    id: "2",
    title: "Retrato Elegante",
    price: 1250,
    image: "https://images.unsplash.com/photo-1767256483514-76135f5a0713?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwb2lsJTIwcGFpbnRlbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc3NDUzMDg4MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    images: [
      "https://images.unsplash.com/photo-1767256483514-76135f5a0713?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwb2lsJTIwcGFpbnRpbmclMjBwb3J0cmFpdHxlbnwxfHx8fDE3NzQ1MzA4ODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    ],
    category: "Retrato",
    year: 2025,
    dimensions: {
      width: 80,
      height: 100,
      depth: 4
    },
    technique: "Óleo sobre lienzo",
    materials: ["Óleo profesional", "Lienzo italiano de lino", "Bastidor reforzado"],
    description: "Un retrato expresivo que combina la técnica clásica del óleo con una interpretación contemporánea. Cada pincelada está pensada para capturar no solo los rasgos físicos, sino la esencia emocional del sujeto.",
    inspiration: "Inspirada en los grandes maestros del retrato, esta obra es mi homenaje a la figura humana y su capacidad infinita de expresar emociones a través de gestos sutiles y miradas profundas.",
    available: true,
    edition: "Pieza única",
    frameOptions: [
      { id: "none", name: "Sin marco", price: 0 },
      { id: "gold", name: "Marco dorado clásico", price: 180 },
      { id: "dark", name: "Marco oscuro tradicional", price: 150 }
    ]
  },
  {
    id: "3",
    title: "Paisaje Montañoso",
    price: 750,
    image: "https://images.unsplash.com/photo-1765133883281-38702fb0daf9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYW5kc2NhcGUlMjBwYWludGluZyUyMG1vdW50YWluc3xlbnwxfHx8fDE3NzQ1MzA4ODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    images: [
      "https://images.unsplash.com/photo-1765133883281-38702fb0daf9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYW5kc2NhcGUlMjBwYWludGluZyUyMG1vdW50YWluc3xlbnwxfHx8fDE3NzQ1MzA4ODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    ],
    category: "Paisaje",
    year: 2024,
    dimensions: {
      width: 120,
      height: 80,
      depth: 4
    },
    technique: "Acrílico y técnica mixta",
    materials: ["Acrílico", "Pastel al óleo", "Lienzo de algodón", "Barniz protector UV"],
    description: "Un paisaje que captura la majestuosidad de las montañas con una paleta de colores moderna y vibrante. La combinación de acrílico y pastel crea profundidad y movimiento.",
    inspiration: "Durante una expedición a los Pirineos, quedé fascinada por cómo la luz del amanecer transformaba las montañas en una paleta de colores cambiantes. Esta obra intenta capturar ese momento mágico de transformación.",
    available: true,
    edition: "Pieza única",
    frameOptions: [
      { id: "none", name: "Sin marco", price: 0 },
      { id: "natural", name: "Marco natural de roble", price: 150 },
      { id: "black", name: "Marco negro", price: 120 }
    ]
  },
  {
    id: "4",
    title: "Minimalismo Azul",
    price: 680,
    image: "https://images.unsplash.com/photo-1769461766792-3993f0ab1b02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYWJzdHJhY3QlMjBhcnQlMjBibHVlfGVufDF8fHx8MTc3NDUzMDg4Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    images: [
      "https://images.unsplash.com/photo-1769461766792-3993f0ab1b02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYWJzdHJhY3QlMjBhcnQlMjBibHVlfGVufDF8fHx8MTc3NDUzMDg4Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    ],
    category: "Minimalista",
    year: 2025,
    dimensions: {
      width: 90,
      height: 90,
      depth: 4
    },
    technique: "Acrílico sobre lienzo",
    materials: ["Acrílico", "Lienzo preparado con gesso", "Barniz mate"],
    description: "Una exploración del minimalismo donde menos es definitivamente más. Los tonos azules crean un ambiente sereno y contemplativo, perfecto para espacios modernos que buscan transmitir calma.",
    inspiration: "Esta serie minimalista surge de mi fascinación por la simplicidad japonesa y la filosofía del 'ma' (間), el espacio negativo. Cada elemento está cuidadosamente colocado para crear equilibrio y armonía.",
    available: true,
    edition: "Pieza única",
    frameOptions: [
      { id: "none", name: "Sin marco", price: 0 },
      { id: "white", name: "Marco blanco flotante", price: 110 },
      { id: "black", name: "Marco negro fino", price: 100 }
    ]
  }
];

export function getArtworkById(id: string): Artwork | undefined {
  return artworks.find(artwork => artwork.id === id);
}
