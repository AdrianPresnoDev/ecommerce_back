import { HeroSection } from '../components/HeroSection';
import { FeaturedGallery } from '../components/FeaturedGallery';
import { AboutSection } from '../components/AboutSection';
import { CollectionsSection } from '../components/CollectionsSection';
import { TestimonialsSection } from '../components/TestimonialsSection';
import { CTASection } from '../components/CTASection';

export function Home() {
  return (
    <>
      <HeroSection />
      <FeaturedGallery />
      <AboutSection />
      <CollectionsSection />
      <TestimonialsSection />
      <CTASection />
    </>
  );
}
