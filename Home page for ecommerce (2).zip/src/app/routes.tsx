import { createBrowserRouter } from 'react-router';
import { Home } from './pages/Home';
import { ArtworkDetail } from './components/ArtworkDetail';
import { CollectionPage } from './components/CollectionPage';
import { Header } from './components/Header';
import { Footer } from './components/Footer';

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen">
      <Header />
      <main>{children}</main>
      <Footer />
    </div>
  );
}

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout><Home /></Layout>,
  },
  {
    path: '/obra/:id',
    element: <Layout><ArtworkDetail /></Layout>,
  },
  {
    path: '/coleccion/:slug',
    element: <Layout><CollectionPage /></Layout>,
  },
]);