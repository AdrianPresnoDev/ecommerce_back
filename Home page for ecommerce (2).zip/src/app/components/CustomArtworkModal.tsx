import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Palette, Send, Upload } from 'lucide-react';

interface CustomArtworkModalProps {
  isOpen: boolean;
  onClose: () => void;
  collectionName?: string;
}

export function CustomArtworkModal({ isOpen, onClose, collectionName }: CustomArtworkModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    artworkType: collectionName || '',
    dimensions: '',
    colorPreferences: '',
    budget: '',
    description: '',
    timeline: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setIsSuccess(true);

    setTimeout(() => {
      setIsSuccess(false);
      onClose();
      setFormData({
        name: '',
        email: '',
        phone: '',
        artworkType: '',
        dimensions: '',
        colorPreferences: '',
        budget: '',
        description: '',
        timeline: ''
      });
    }, 2500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div className="sticky top-0 bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6 flex justify-between items-center rounded-t-2xl">
                <div>
                  <h2 className="text-3xl font-serif mb-1">Obra Personalizada</h2>
                  <p className="text-purple-100">Creemos juntos tu pieza única</p>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Content */}
              <div className="p-6">
                {isSuccess ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-12"
                  >
                    <div className="w-16 h-16 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Palette className="w-8 h-8 text-purple-600" />
                    </div>
                    <h3 className="text-2xl font-serif mb-2">¡Solicitud recibida!</h3>
                    <p className="text-gray-600 mb-4">
                      Inma revisará tu solicitud y te contactará en breve para discutir los detalles de tu obra personalizada.
                    </p>
                    <p className="text-sm text-gray-500">
                      Recibirás un email de confirmación en los próximos minutos.
                    </p>
                  </motion.div>
                ) : (
                  <>
                    {/* Info Banner */}
                    <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-4 mb-6">
                      <div className="flex gap-3">
                        <Palette className="w-6 h-6 text-purple-600 flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-1">¿Cómo funciona?</h3>
                          <p className="text-sm text-gray-600">
                            Completa este formulario con tu visión y preferencias. Inma se pondrá en contacto contigo
                            para discutir los detalles, compartir bocetos y acordar el presupuesto final.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Form */}
                    <form onSubmit={handleSubmit} className="space-y-6">
                      {/* Personal Info */}
                      <div className="space-y-4">
                        <h3 className="font-semibold text-lg">Información de Contacto</h3>
                        
                        <div>
                          <label htmlFor="name" className="block text-sm font-semibold mb-2">
                            Nombre completo *
                          </label>
                          <input
                            type="text"
                            id="name"
                            name="name"
                            required
                            value={formData.name}
                            onChange={handleChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors"
                            placeholder="Tu nombre"
                          />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label htmlFor="email" className="block text-sm font-semibold mb-2">
                              Email *
                            </label>
                            <input
                              type="email"
                              id="email"
                              name="email"
                              required
                              value={formData.email}
                              onChange={handleChange}
                              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors"
                              placeholder="tu@email.com"
                            />
                          </div>

                          <div>
                            <label htmlFor="phone" className="block text-sm font-semibold mb-2">
                              Teléfono *
                            </label>
                            <input
                              type="tel"
                              id="phone"
                              name="phone"
                              required
                              value={formData.phone}
                              onChange={handleChange}
                              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors"
                              placeholder="+34 123 456 789"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Artwork Details */}
                      <div className="space-y-4 pt-4 border-t border-gray-200">
                        <h3 className="font-semibold text-lg">Detalles de la Obra</h3>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label htmlFor="artworkType" className="block text-sm font-semibold mb-2">
                              Tipo de obra *
                            </label>
                            <select
                              id="artworkType"
                              name="artworkType"
                              required
                              value={formData.artworkType}
                              onChange={handleChange}
                              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors"
                            >
                              <option value="">Selecciona un estilo</option>
                              <option value="Abstracto">Abstracto Contemporáneo</option>
                              <option value="Retrato">Retrato Expresivo</option>
                              <option value="Paisaje">Paisaje Onírico</option>
                              <option value="Minimalista">Minimalismo Moderno</option>
                              <option value="Otro">Otro estilo</option>
                            </select>
                          </div>

                          <div>
                            <label htmlFor="dimensions" className="block text-sm font-semibold mb-2">
                              Dimensiones aproximadas *
                            </label>
                            <input
                              type="text"
                              id="dimensions"
                              name="dimensions"
                              required
                              value={formData.dimensions}
                              onChange={handleChange}
                              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors"
                              placeholder="ej: 100x80 cm"
                            />
                          </div>
                        </div>

                        <div>
                          <label htmlFor="colorPreferences" className="block text-sm font-semibold mb-2">
                            Preferencias de color
                          </label>
                          <input
                            type="text"
                            id="colorPreferences"
                            name="colorPreferences"
                            value={formData.colorPreferences}
                            onChange={handleChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors"
                            placeholder="ej: Tonos cálidos, azules y dorados"
                          />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label htmlFor="budget" className="block text-sm font-semibold mb-2">
                              Presupuesto aproximado *
                            </label>
                            <select
                              id="budget"
                              name="budget"
                              required
                              value={formData.budget}
                              onChange={handleChange}
                              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors"
                            >
                              <option value="">Selecciona un rango</option>
                              <option value="1000-2500">€1.000 - €2.500</option>
                              <option value="2500-5000">€2.500 - €5.000</option>
                              <option value="5000-10000">€5.000 - €10.000</option>
                              <option value="10000+">Más de €10.000</option>
                            </select>
                          </div>

                          <div>
                            <label htmlFor="timeline" className="block text-sm font-semibold mb-2">
                              Fecha límite
                            </label>
                            <input
                              type="date"
                              id="timeline"
                              name="timeline"
                              value={formData.timeline}
                              onChange={handleChange}
                              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors"
                            />
                          </div>
                        </div>

                        <div>
                          <label htmlFor="description" className="block text-sm font-semibold mb-2">
                            Describe tu visión *
                          </label>
                          <textarea
                            id="description"
                            name="description"
                            required
                            value={formData.description}
                            onChange={handleChange}
                            rows={6}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors resize-none"
                            placeholder="Cuéntame sobre tu visión, el espacio donde irá la obra, qué emociones quieres transmitir, referencias que te inspiran..."
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-semibold mb-2">
                            Imágenes de referencia (opcional)
                          </label>
                          <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-purple-400 transition-colors cursor-pointer">
                            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                            <p className="text-sm text-gray-600 mb-1">
                              Arrastra imágenes aquí o haz clic para seleccionar
                            </p>
                            <p className="text-xs text-gray-500">
                              PNG, JPG hasta 10MB
                            </p>
                          </div>
                        </div>
                      </div>

                      <motion.button
                        type="submit"
                        disabled={isSubmitting}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-4 rounded-full font-semibold hover:from-purple-700 hover:to-pink-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                      >
                        {isSubmitting ? (
                          <>
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            Enviando solicitud...
                          </>
                        ) : (
                          <>
                            <Send className="w-5 h-5" />
                            Enviar Solicitud
                          </>
                        )}
                      </motion.button>

                      <p className="text-xs text-gray-500 text-center">
                        * Campos obligatorios. Tu información será tratada con total confidencialidad.
                      </p>
                    </form>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
