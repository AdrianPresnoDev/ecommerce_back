import { motion, AnimatePresence } from 'motion/react';
import { X, DollarSign, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { useState } from 'react';

interface MakeOfferModalProps {
  isOpen: boolean;
  onClose: () => void;
  artworkTitle: string;
  originalPrice: number;
  framePrice: number;
  onOfferSubmitted: (offerPrice: number) => void;
}

export function MakeOfferModal({
  isOpen,
  onClose,
  artworkTitle,
  originalPrice,
  framePrice,
  onOfferSubmitted
}: MakeOfferModalProps) {
  const [offerPrice, setOfferPrice] = useState<string>('');
  const [message, setMessage] = useState('');

  const totalOriginalPrice = originalPrice + framePrice;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const price = parseFloat(offerPrice);
    
    if (isNaN(price) || price <= 0) {
      return;
    }

    onOfferSubmitted(price);
    setOfferPrice('');
    setMessage('');
    onClose();
  };

  const offerValue = parseFloat(offerPrice) || 0;
  const difference = offerValue - totalOriginalPrice;
  const percentageDiff = ((difference / totalOriginalPrice) * 100).toFixed(1);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 z-50 backdrop-blur-sm"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={onClose}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden"
            >
              {/* Header */}
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6 relative">
                <button
                  onClick={onClose}
                  className="absolute top-4 right-4 p-2 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="flex items-center gap-3 mb-2">
                  <DollarSign className="w-8 h-8" />
                  <h2 className="text-2xl font-serif">Proponer Precio</h2>
                </div>
                <p className="text-sm text-white/90">{artworkTitle}</p>
              </div>

              {/* Content */}
              <form onSubmit={handleSubmit} className="p-6 space-y-6">
                {/* Original Price Info */}
                <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Precio de la obra:</span>
                    <span className="font-semibold">€{originalPrice.toLocaleString()}</span>
                  </div>
                  {framePrice > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Marco seleccionado:</span>
                      <span className="font-semibold">€{framePrice.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg pt-2 border-t border-gray-200">
                    <span className="font-semibold">Precio total actual:</span>
                    <span className="font-bold">€{totalOriginalPrice.toLocaleString()}</span>
                  </div>
                </div>

                {/* Offer Input */}
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Tu Oferta (€)
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-lg">
                      €
                    </span>
                    <input
                      type="number"
                      value={offerPrice}
                      onChange={(e) => setOfferPrice(e.target.value)}
                      placeholder="Introduce tu precio"
                      min="1"
                      step="0.01"
                      required
                      className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none text-lg"
                    />
                  </div>

                  {/* Price Difference Indicator */}
                  {offerValue > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`mt-2 flex items-center gap-2 text-sm ${
                        difference > 0
                          ? 'text-green-600'
                          : difference < 0
                          ? 'text-orange-600'
                          : 'text-gray-600'
                      }`}
                    >
                      {difference > 0 ? (
                        <>
                          <CheckCircle className="w-4 h-4" />
                          <span>
                            +€{Math.abs(difference).toLocaleString()} ({percentageDiff}% más)
                          </span>
                        </>
                      ) : difference < 0 ? (
                        <>
                          <AlertCircle className="w-4 h-4" />
                          <span>
                            -€{Math.abs(difference).toLocaleString()} ({Math.abs(parseFloat(percentageDiff))}% menos)
                          </span>
                        </>
                      ) : (
                        <span>Precio igual al actual</span>
                      )}
                    </motion.div>
                  )}
                </div>

                {/* Message */}
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Mensaje para la Artista (Opcional)
                  </label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Cuéntale a Inma por qué te interesa esta obra..."
                    rows={3}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none resize-none"
                  />
                </div>

                {/* Info Box */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-800">
                    <Clock className="w-4 h-4 inline mr-2" />
                    {offerValue < totalOriginalPrice
                      ? 'Tu oferta será revisada por Inma Álvarez. Recibirás una respuesta en breve.'
                      : 'Al ofrecer un precio igual o superior, tu compra puede procesarse directamente.'}
                  </p>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 px-6 py-3 border-2 border-gray-300 rounded-full hover:bg-gray-50 transition-colors font-semibold"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-full hover:from-purple-700 hover:to-pink-700 transition-colors font-semibold"
                  >
                    Enviar Oferta
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
