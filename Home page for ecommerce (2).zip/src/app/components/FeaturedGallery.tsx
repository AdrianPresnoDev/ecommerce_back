import { motion } from 'motion/react';
import { Heart, ShoppingCart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState } from 'react';
import { Link } from 'react-router';
import { artworks } from '../data/artworks';

export function FeaturedGallery() {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  return (
    <section id="galeria" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-serif mb-4">Obras Destacadas</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Cada pieza es única, creada con pasión y dedicación para convertirse en el centro de atención de tu espacio
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {artworks.map((artwork, index) => (
            <motion.div
              key={artwork.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group cursor-pointer"
              onMouseEnter={() => setHoveredId(artwork.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              <Link to={`/obra/${artwork.id}`}>
                <div className="relative overflow-hidden rounded-lg bg-white shadow-lg">
                  <div className="aspect-[3/4] relative">
                    <ImageWithFallback
                      src={artwork.image}
                      alt={artwork.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    
                    {/* Overlay on hover */}
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: hoveredId === artwork.id ? 1 : 0 }}
                      className="absolute inset-0 bg-black/40 flex items-center justify-center gap-4"
                    >
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="bg-white p-3 rounded-full hover:bg-gray-100 transition-colors"
                        onClick={(e) => e.preventDefault()}
                      >
                        <Heart className="w-5 h-5" />
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="bg-white p-3 rounded-full hover:bg-gray-100 transition-colors"
                        onClick={(e) => e.preventDefault()}
                      >
                        <ShoppingCart className="w-5 h-5" />
                      </motion.button>
                    </motion.div>
                  </div>

                  <div className="p-4">
                    <span className="text-sm text-gray-500">{artwork.category}</span>
                    <h3 className="text-xl font-serif mt-1 mb-2">{artwork.title}</h3>
                    <p className="text-2xl">€{artwork.price.toLocaleString()}</p>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-12">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-black text-white px-8 py-4 rounded-full hover:bg-gray-800 transition-colors"
          >
            Ver Toda la Colección
          </motion.button>
        </div>
      </div>
    </section>
  );
}