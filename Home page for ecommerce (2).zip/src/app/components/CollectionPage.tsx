import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { ArrowLeft, SlidersHorizontal, Grid3x3, Grid2x2, Heart, ShoppingCart, ChevronDown } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { getCollectionBySlug } from '../data/collections';
import { artworks } from '../data/artworks';
import { ContactModal } from './ContactModal';
import { CustomArtworkModal } from './CustomArtworkModal';

type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'newest';
type ViewMode = 'grid-3' | 'grid-4';

export function CollectionPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const collection = slug ? getCollectionBySlug(slug) : undefined;

  const [sortBy, setSortBy] = useState<SortOption>('featured');
  const [viewMode, setViewMode] = useState<ViewMode>('grid-3');
  const [showFilters, setShowFilters] = useState(false);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isCustomArtworkModalOpen, setIsCustomArtworkModalOpen] = useState(false);

  if (!collection) {
    return (
      <div className="min-h-screen pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-serif mb-4">Colección no encontrada</h1>
          <Link to="/" className="text-blue-600 hover:underline">
            Volver al inicio
          </Link>
        </div>
      </div>
    );
  }

  // Filter artworks by collection category
  const collectionArtworks = artworks.filter(
    artwork => artwork.category === collection.category
  );

  // Sort artworks
  const sortedArtworks = [...collectionArtworks].sort((a, b) => {
    switch (sortBy) {
      case 'price-asc':
        return a.price - b.price;
      case 'price-desc':
        return b.price - a.price;
      case 'newest':
        return b.year - a.year;
      default:
        return 0;
    }
  });

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <div className={`relative h-[60vh] flex items-center justify-center overflow-hidden bg-gradient-to-br ${collection.color}`}>
        <div className="absolute inset-0 opacity-20">
          <ImageWithFallback
            src={collection.heroImage}
            alt={collection.title}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <button
              onClick={() => navigate(-1)}
              className="mb-6 flex items-center gap-2 text-white/90 hover:text-white transition-colors mx-auto"
            >
              <ArrowLeft className="w-5 h-5" />
              Volver
            </button>
            
            <h1 className="text-5xl md:text-6xl font-serif mb-6">{collection.title}</h1>
            <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-2xl mx-auto">
              {collection.longDescription}
            </p>
            <div className="flex items-center justify-center gap-2 text-lg">
              <span className="font-semibold">{collectionArtworks.length}</span>
              <span>obras disponibles</span>
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            <ChevronDown className="w-8 h-8 text-white" />
          </motion.div>
        </motion.div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Controls Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-12 pb-6 border-b border-gray-200"
        >
          <div>
            <p className="text-gray-600">
              Mostrando <span className="font-semibold text-gray-900">{sortedArtworks.length}</span> obras
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            {/* Sort Dropdown */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="appearance-none bg-white border-2 border-gray-200 rounded-full px-6 py-2 pr-10 font-semibold text-sm hover:border-gray-300 focus:outline-none focus:border-black cursor-pointer"
              >
                <option value="featured">Destacadas</option>
                <option value="newest">Más Recientes</option>
                <option value="price-asc">Precio: Menor a Mayor</option>
                <option value="price-desc">Precio: Mayor a Menor</option>
              </select>
              <ChevronDown className="w-4 h-4 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center gap-2 bg-gray-100 rounded-full p-1">
              <button
                onClick={() => setViewMode('grid-3')}
                className={`p-2 rounded-full transition-colors ${
                  viewMode === 'grid-3' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                }`}
                title="Vista 3 columnas"
              >
                <Grid3x3 className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('grid-4')}
                className={`p-2 rounded-full transition-colors ${
                  viewMode === 'grid-4' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                }`}
                title="Vista 4 columnas"
              >
                <Grid2x2 className="w-5 h-5" />
              </button>
            </div>

            {/* Filters Button */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 border-2 border-gray-200 rounded-full px-6 py-2 font-semibold text-sm hover:border-gray-300 transition-colors"
            >
              <SlidersHorizontal className="w-4 h-4" />
              Filtros
            </button>
          </div>
        </motion.div>

        {/* Filters Panel */}
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-12 p-6 bg-gray-50 rounded-2xl"
          >
            <h3 className="font-semibold mb-4">Filtrar por:</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-semibold mb-2">Rango de Precio</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Mín"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-black"
                  />
                  <input
                    type="number"
                    placeholder="Máx"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-black"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Disponibilidad</label>
                <div className="space-y-2">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" defaultChecked />
                    <span className="text-sm">Disponible ahora</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" />
                    <span className="text-sm">Próximamente</span>
                  </label>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Tamaño</label>
                <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-black">
                  <option>Todos los tamaños</option>
                  <option>Pequeño (&lt; 50cm)</option>
                  <option>Mediano (50-100cm)</option>
                  <option>Grande (&gt; 100cm)</option>
                </select>
              </div>
            </div>
          </motion.div>
        )}

        {/* Artworks Grid */}
        <div className={`grid grid-cols-1 ${
          viewMode === 'grid-3' ? 'md:grid-cols-2 lg:grid-cols-3' : 'md:grid-cols-2 lg:grid-cols-4'
        } gap-8`}>
          {sortedArtworks.map((artwork, index) => (
            <motion.div
              key={artwork.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="group"
              onMouseEnter={() => setHoveredId(artwork.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              <Link to={`/obra/${artwork.id}`}>
                <div className="relative overflow-hidden rounded-2xl bg-white shadow-lg hover:shadow-2xl transition-shadow duration-300">
                  <div className="aspect-[3/4] relative">
                    <ImageWithFallback
                      src={artwork.image}
                      alt={artwork.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    
                    {/* Overlay on hover */}
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: hoveredId === artwork.id ? 1 : 0 }}
                      className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent flex flex-col justify-end p-6"
                    >
                      <div className="flex gap-2 mb-4">
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="bg-white p-3 rounded-full hover:bg-gray-100 transition-colors"
                          onClick={(e) => e.preventDefault()}
                        >
                          <Heart className="w-5 h-5" />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="bg-white p-3 rounded-full hover:bg-gray-100 transition-colors"
                          onClick={(e) => e.preventDefault()}
                        >
                          <ShoppingCart className="w-5 h-5" />
                        </motion.button>
                      </div>
                    </motion.div>

                    {/* Badge */}
                    {artwork.available && (
                      <div className="absolute top-4 right-4 bg-green-500 text-white text-xs px-3 py-1 rounded-full font-semibold">
                        Disponible
                      </div>
                    )}
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-serif mb-2 group-hover:text-gray-600 transition-colors">
                      {artwork.title}
                    </h3>
                    <p className="text-sm text-gray-500 mb-3">{artwork.year}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-serif">€{artwork.price.toLocaleString()}</span>
                      <span className="text-sm text-gray-500">
                        {artwork.dimensions.width} × {artwork.dimensions.height} cm
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Empty State */}
        {sortedArtworks.length === 0 && (
          <div className="text-center py-20">
            <p className="text-xl text-gray-600 mb-4">No se encontraron obras en esta colección</p>
            <Link to="/" className="text-blue-600 hover:underline">
              Explorar todas las colecciones
            </Link>
          </div>
        )}

        {/* Collection Info Footer */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-20 bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl p-8 md:p-12"
        >
          <div className="max-w-3xl mx-auto text-center">
            <h3 className="text-3xl font-serif mb-4">¿Buscas algo específico?</h3>
            <p className="text-lg text-gray-600 mb-6">
              Si no encuentras la obra perfecta o deseas una pieza personalizada de esta colección,
              estaré encantada de crear algo único para ti.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-black text-white px-8 py-4 rounded-full font-semibold hover:bg-gray-800 transition-colors"
                onClick={() => setIsCustomArtworkModalOpen(true)}
              >
                Solicitar Obra Personalizada
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="border-2 border-black text-black px-8 py-4 rounded-full font-semibold hover:bg-black hover:text-white transition-colors"
                onClick={() => setIsContactModalOpen(true)}
              >
                Contactar a Inma
              </motion.button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Contact Modal */}
      <ContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
      />

      {/* Custom Artwork Modal */}
      <CustomArtworkModal
        isOpen={isCustomArtworkModalOpen}
        onClose={() => setIsCustomArtworkModalOpen(false)}
      />
    </div>
  );
}