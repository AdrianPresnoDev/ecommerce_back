import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { ArrowLeft, Heart, Share2, ShoppingCart, Check, Truck, Award, Info, Tag, Clock, CheckCircle, XCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { getArtworkById, artworks } from '../data/artworks';
import { MakeOfferModal } from './MakeOfferModal';

type OfferStatus = 'none' | 'pending' | 'accepted' | 'rejected';

export function ArtworkDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const artwork = id ? getArtworkById(id) : undefined;

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedFrame, setSelectedFrame] = useState('none');
  const [quantity, setQuantity] = useState(1);
  const [isOfferModalOpen, setIsOfferModalOpen] = useState(false);
  const [offerStatus, setOfferStatus] = useState<OfferStatus>('none');
  const [offerPrice, setOfferPrice] = useState<number>(0);
  const [isProcessingOffer, setIsProcessingOffer] = useState(false);

  if (!artwork) {
    return (
      <div className="min-h-screen pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-serif mb-4">Obra no encontrada</h1>
          <Link to="/" className="text-blue-600 hover:underline">
            Volver al inicio
          </Link>
        </div>
      </div>
    );
  }

  const framePrice = artwork.frameOptions.find(f => f.id === selectedFrame)?.price || 0;
  const totalPrice = (artwork.price + framePrice) * quantity;
  const displayPrice = offerStatus === 'accepted' ? offerPrice : totalPrice;

  // Related artworks (same category, different id)
  const relatedArtworks = artworks.filter(
    a => a.category === artwork.category && a.id !== artwork.id
  ).slice(0, 3);

  // Simulate artist's response to the offer
  const handleOfferSubmitted = (price: number) => {
    setOfferPrice(price);
    setOfferStatus('pending');
    setIsProcessingOffer(true);

    // Simulate processing time (2-4 seconds)
    setTimeout(() => {
      const discountPercentage = ((totalPrice - price) / totalPrice) * 100;
      
      // Logic: Accept offers with up to 15% discount, reject higher discounts, always accept higher prices
      if (price >= totalPrice) {
        setOfferStatus('accepted');
      } else if (discountPercentage <= 15) {
        setOfferStatus('accepted');
      } else {
        setOfferStatus('rejected');
      }
      
      setIsProcessingOffer(false);
    }, Math.random() * 2000 + 2000); // 2-4 seconds
  };

  const resetOffer = () => {
    setOfferStatus('none');
    setOfferPrice(0);
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Back Button */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Volver
        </motion.button>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Image Gallery */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="sticky top-24">
              {/* Main Image */}
              <div className="aspect-square rounded-2xl overflow-hidden bg-gray-100 mb-4">
                <ImageWithFallback
                  src={artwork.images[selectedImage]}
                  alt={`${artwork.title} - Vista ${selectedImage + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Thumbnail Gallery */}
              {artwork.images.length > 1 && (
                <div className="grid grid-cols-4 gap-4">
                  {artwork.images.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(index)}
                      className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                        selectedImage === index
                          ? 'border-black scale-95'
                          : 'border-transparent hover:border-gray-300'
                      }`}
                    >
                      <ImageWithFallback
                        src={image}
                        alt={`${artwork.title} - Miniatura ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-8"
          >
            {/* Header */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">{artwork.category}</span>
                <div className="flex gap-2">
                  <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <Heart className="w-5 h-5" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <Share2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <h1 className="text-4xl md:text-5xl font-serif mb-2">{artwork.title}</h1>
              <p className="text-gray-600">
                por <span className="font-semibold">Inma Álvarez</span> • {artwork.year}
              </p>
              <div className="mt-4">
                <span className="text-4xl font-serif">€{displayPrice.toLocaleString()}</span>
                {framePrice > 0 && offerStatus !== 'accepted' && (
                  <span className="text-sm text-gray-500 ml-2">
                    (incluye marco: +€{framePrice})
                  </span>
                )}
                {offerStatus === 'accepted' && offerPrice !== totalPrice && (
                  <span className="text-sm text-green-600 ml-2">
                    (precio negociado)
                  </span>
                )}
              </div>
            </div>

            {/* Offer Status Messages */}
            {offerStatus === 'pending' && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 flex items-start gap-3"
              >
                <Clock className="w-5 h-5 text-blue-600 mt-0.5 animate-pulse" />
                <div className="flex-1">
                  <h4 className="font-semibold text-blue-900 mb-1">Oferta en Revisión</h4>
                  <p className="text-sm text-blue-700">
                    Tu oferta de €{offerPrice.toLocaleString()} está siendo revisada por Inma Álvarez. 
                    {isProcessingOffer && ' Espera un momento...'}
                  </p>
                </div>
              </motion.div>
            )}

            {offerStatus === 'accepted' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-green-50 border-2 border-green-200 rounded-xl p-4 flex items-start gap-3"
              >
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-semibold text-green-900 mb-1">¡Oferta Aceptada!</h4>
                  <p className="text-sm text-green-700 mb-3">
                    Inma ha aceptado tu oferta de €{offerPrice.toLocaleString()}. 
                    {offerPrice > totalPrice 
                      ? ' ¡Gracias por tu generosidad!' 
                      : ' Ahora puedes proceder con la compra al precio acordado.'}
                  </p>
                  <button
                    onClick={resetOffer}
                    className="text-xs text-green-700 underline hover:text-green-900"
                  >
                    Volver al precio original
                  </button>
                </div>
              </motion.div>
            )}

            {offerStatus === 'rejected' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-red-50 border-2 border-red-200 rounded-xl p-4 flex items-start gap-3"
              >
                <XCircle className="w-5 h-5 text-red-600 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-semibold text-red-900 mb-1">Oferta No Aceptada</h4>
                  <p className="text-sm text-red-700 mb-3">
                    Lamentablemente, Inma no puede aceptar tu oferta de €{offerPrice.toLocaleString()} en este momento. 
                    El precio de esta obra refleja las horas de trabajo, materiales premium y su valor artístico único.
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        resetOffer();
                        setIsOfferModalOpen(true);
                      }}
                      className="text-xs text-red-700 underline hover:text-red-900"
                    >
                      Hacer otra oferta
                    </button>
                    <span className="text-xs text-red-400">•</span>
                    <button
                      onClick={resetOffer}
                      className="text-xs text-red-700 underline hover:text-red-900"
                    >
                      Comprar al precio original
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Availability Badge */}
            {artwork.available && (
              <div className="flex items-center gap-2 text-green-600">
                <Check className="w-5 h-5" />
                <span className="font-semibold">Disponible • {artwork.edition}</span>
              </div>
            )}

            {/* Description */}
            <div className="space-y-4">
              <div>
                <h3 className="text-xl font-serif mb-2">Sobre la Obra</h3>
                <p className="text-gray-700 leading-relaxed">{artwork.description}</p>
              </div>
              <div className="bg-gray-50 p-6 rounded-xl">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <Info className="w-5 h-5" />
                  Inspiración de la Artista
                </h4>
                <p className="text-gray-700 leading-relaxed italic">{artwork.inspiration}</p>
              </div>
            </div>

            {/* Technical Details */}
            <div className="border-t border-b border-gray-200 py-6 space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Técnica:</span>
                <span className="font-semibold">{artwork.technique}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Dimensiones:</span>
                <span className="font-semibold">
                  {artwork.dimensions.width} × {artwork.dimensions.height} × {artwork.dimensions.depth} cm
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Año:</span>
                <span className="font-semibold">{artwork.year}</span>
              </div>
              <div>
                <span className="text-gray-600">Materiales:</span>
                <ul className="mt-2 space-y-1">
                  {artwork.materials.map((material, index) => (
                    <li key={index} className="text-sm text-gray-700 ml-4">• {material}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Frame Options */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Opciones de Enmarcado</h3>
              <div className="grid grid-cols-2 gap-3">
                {artwork.frameOptions.map((frame) => (
                  <button
                    key={frame.id}
                    onClick={() => setSelectedFrame(frame.id)}
                    className={`p-4 rounded-lg border-2 text-left transition-all ${
                      selectedFrame === frame.id
                        ? 'border-black bg-gray-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="font-semibold text-sm mb-1">{frame.name}</div>
                    <div className="text-sm text-gray-600">
                      {frame.price === 0 ? 'Incluido' : `+€${frame.price}`}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity (only if available) */}
            {artwork.edition === "Pieza única" ? (
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-lg">
                <p className="text-sm text-amber-800">
                  <Award className="w-4 h-4 inline mr-2" />
                  Esta es una pieza única y original, no existen copias ni reproducciones.
                </p>
              </div>
            ) : (
              <div>
                <label className="text-lg font-semibold mb-3 block">Cantidad</label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 border border-gray-300 rounded-lg hover:bg-gray-100"
                  >
                    -
                  </button>
                  <span className="text-xl font-semibold w-12 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 border border-gray-300 rounded-lg hover:bg-gray-100"
                  >
                    +
                  </button>
                </div>
              </div>
            )}

            {/* Add to Cart Button */}
            <div className="space-y-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full bg-black text-white py-4 rounded-full font-semibold flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={offerStatus === 'pending'}
              >
                <ShoppingCart className="w-5 h-5" />
                {offerStatus === 'pending' 
                  ? 'Esperando respuesta...' 
                  : offerStatus === 'accepted'
                  ? `Añadir al Carrito (€${displayPrice.toLocaleString()})`
                  : 'Añadir al Carrito'}
              </motion.button>
              
              <div className="grid grid-cols-2 gap-3">
                <button 
                  className="w-full border-2 border-black text-black py-4 rounded-full font-semibold hover:bg-black hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={offerStatus === 'pending'}
                >
                  Comprar Ahora
                </button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setIsOfferModalOpen(true)}
                  className="w-full border-2 border-purple-600 text-purple-600 py-4 rounded-full font-semibold hover:bg-purple-600 hover:text-white transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={offerStatus === 'pending'}
                >
                  <Tag className="w-5 h-5" />
                  Proponer Precio
                </motion.button>
              </div>
            </div>

            {/* Shipping & Certificates Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <Truck className="w-5 h-5 mt-1 text-gray-600" />
                <div>
                  <h4 className="font-semibold text-sm mb-1">Envío Asegurado</h4>
                  <p className="text-xs text-gray-600">
                    Embalaje profesional y seguro de transporte incluido
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <Award className="w-5 h-5 mt-1 text-gray-600" />
                <div>
                  <h4 className="font-semibold text-sm mb-1">Certificado de Autenticidad</h4>
                  <p className="text-xs text-gray-600">
                    Firmado y numerado por la artista
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Related Artworks */}
        {relatedArtworks.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-20"
          >
            <h2 className="text-3xl font-serif mb-8">Obras Relacionadas</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {relatedArtworks.map((relatedArtwork) => (
                <Link
                  key={relatedArtwork.id}
                  to={`/obra/${relatedArtwork.id}`}
                  className="group"
                >
                  <div className="aspect-[3/4] rounded-lg overflow-hidden bg-gray-100 mb-4">
                    <ImageWithFallback
                      src={relatedArtwork.image}
                      alt={relatedArtwork.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <h3 className="text-xl font-serif mb-1">{relatedArtwork.title}</h3>
                  <p className="text-gray-600">€{relatedArtwork.price.toLocaleString()}</p>
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </div>

      {/* Make Offer Modal */}
      <MakeOfferModal
        isOpen={isOfferModalOpen}
        onClose={() => setIsOfferModalOpen(false)}
        artworkTitle={artwork.title}
        originalPrice={artwork.price}
        framePrice={framePrice}
        onOfferSubmitted={handleOfferSubmitted}
      />
    </div>
  );
}