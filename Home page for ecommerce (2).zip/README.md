
  # Home page for ecommerce

  This is a code bundle for Home page for ecommerce. The original project is available at https://www.figma.com/design/RRy1EH06euAYgtcErEvCzA/Home-page-for-ecommerce.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  